# FrameFlow 2.1.0 status

Baseline: merged 2.0.2 source, `main` commit `1c26076bf87b3cfa54ef78893d52f32249d3c229`, tree `112d429c22b902126518f564e18f621665da803e`. The user confirmed that 2.0.2 connects in AE 25.6.4 and requested removal of the duplicate timeline and repairs to command usability.

The 2.0.2 primary arrows dispatched whole-region `move` commands. Before/After controls were hidden in whole-layer mode. Auto existed in the timing core but not the UI or CEP gap adapter. UI-derived IDs and stale CTI/selection could also reject commands. The compact panel now always dispatches side-specific offset commands with a validated scope, reads fresh AE state before each command, and keeps host stale-token protection. Close Gap accepts Auto and remains independent of frame step/mode.

The timeline, layer selection UI, drag/trim/split inspector and related keyboard mutations have been removed from the panel. Four directions, actual scope hint, clear mode descriptions, frame presets, stepper/Shift/wheel, slider and rounded time shortcuts are available. Settings v2 migrates v1, preserves explicit timing choices, appearance and 0/false, and adds editable quick steps. Invalid drafts remain in the current session. Clipboard, bootstrap, single-flight transport and uncertain-write recovery are retained.

Irrelevant locked layers are excluded before reporting skips: wrong-side offset layers and key-only layers without matching keys cannot block unrelated work. Relevant locked targets, collisions and read failures still block the whole operation before writes. Legacy host Move/Trim/Split endpoints remain for compatibility and regression checks, but have no panel controls.

See `VERIFICATION.json` and `docs/verification.log` for exact current checks. New functional evidence is simulated AE/CEP/DOM, including all four directions, automatic scope, fresh CTI/selection, gap, locks, modes, drafts, migrated settings and clipboard recovery. The user's 2.0.2 connection confirmation is not a real execution test of 2.1.0. New behavior, native Undo/Redo and desktop layout still require `docs/AE_SMOKE_TEST_RU.md`. Source review is self-review. Publication uses a task branch/PR and preserves issued downloads.

Browser attempt: the public PREVIEW.html on the task branch was submitted to Firecrawl Interact for 320/480 px and open-state checks. The service returned INVALID_ARGUMENT with no session; no successful browser/layout evidence was obtained. No private source or project was uploaded.
